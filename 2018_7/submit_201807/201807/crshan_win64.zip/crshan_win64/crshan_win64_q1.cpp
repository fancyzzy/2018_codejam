#include <stdio.h>
#include <iostream>
using namespace std;

void main()
{
	int i;
	char ch;
	int a[26]= {0};
	int index= 0;
	char str1[1000];
	char str2[1000];

	cin>>str1;
	cin>>str2;
	
	for(i= 0; i< 1000; i++)
	{
		if(str1[i]>= 'a' && str1[i]<= 'z')
		{
			index= str1[i]-'a';
			a[index]++;
		}
	}
	for(i= 0; i< 1000; i++)
	{
		if(str2[i]>= 'a' && str2[i]<= 'z')
		{
			index= str2[i]-'a';
			a[index]--;
		}
	}

	for (i=0; i<26; i++)
	{
		if(a[i] < 0)
		{			
			ch= 'a'+i;		
		}
	}
	cout<<ch<<endl;
}