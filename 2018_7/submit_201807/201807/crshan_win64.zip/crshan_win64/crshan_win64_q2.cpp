#include <stdio.h>
#include <iostream>
using namespace std;

#define MAX(a,b) (((a) > (b)) ? (a) : (b))

int a[100000];
int num[100000]= {0};
int n= 0;

int Solution()
{
	int res= 0;
	int i;
	for(i=0; i< n; i++)
	{
		num[i]= 1;
	}
	for(i= 0; i< n-1; i++)
	{
		if(a[i+1]> a[i])
		{
			num[i+1]= num[i]+1;
		}
	}
	for(i= n-1; i> 0; i--)
	{
		if(a[i-1]> a[i])
		{
			num[i-1]= MAX(num[i]+1, num[i-1]);
		}
	}
	for(i= 0; i< n; i++)
	{
		res+= num[i];
	}
	return res;
}

void main()
{
	int res;

	cin>>a[n++];
	while(getchar()!= '\n')
	{
		cin>>a[n++];
	}
	res= Solution();
	cout<<res<<endl;
}
